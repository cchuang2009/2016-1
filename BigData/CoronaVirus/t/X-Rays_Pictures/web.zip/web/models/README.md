While running the notebook.ipynb ,after the model has been trained save the model as model.save('models/model.h5').
I could not upload my model.h5 file since it was too big, although you can add it locally after cloning the repo.
