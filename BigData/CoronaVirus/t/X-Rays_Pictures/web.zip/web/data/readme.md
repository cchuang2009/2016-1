The zipped data file is around 1.5 GB, go to [Kaggle](https://www.kaggle.com/paultimothymooney/chest-xray-pneumonia), download and unzip the data and keep it in this folder.
