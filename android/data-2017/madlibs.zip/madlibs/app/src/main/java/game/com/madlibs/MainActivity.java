package game.com.madlibs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    private WebView mwebview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mwebview = (WebView) this.findViewById(R.id.webview1);
        mwebview.getSettings().setJavaScriptEnabled(true);
        mwebview.loadUrl("file:///android_asset/index.html");
    }
}
