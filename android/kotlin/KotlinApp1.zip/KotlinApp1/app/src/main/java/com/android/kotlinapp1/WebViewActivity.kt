package com.android.kotlinapp1

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.webkit.WebView
//import android.content.Intent
//import android.webkit.WebViewClient

class WebViewActivity: AppCompatActivity() {

    //private val webview: WebView? = null
    var webview: WebView? = null

    //@SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.webview)

        //val webview = WebView(this)
        //setContentView(webview)
        webview = findViewById<WebView>(R.id.webview01)
        //webview.settings.javaScriptEnabled = true
        /*
        webview!!.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                view?.loadUrl(url)
                return true
            }
        }
        //webview = findViewById(webView01);
        //webView.getSettings().setJavaScriptEnabled(true)
        */
        webview!!.getSettings().setJavaScriptEnabled(true);
        //webview!!.loadUrl("http://www.cgu.edu.tw")
        webview!!.loadUrl("file:///android_asset/index.html")
    }

}