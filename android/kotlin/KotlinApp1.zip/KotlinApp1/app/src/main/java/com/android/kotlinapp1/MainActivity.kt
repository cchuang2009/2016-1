package com.android.kotlinapp1

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private var edittext: EditText?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edittext=findViewById(R.id.edittext01)
    }

    fun onClick(view: View){
        edittext?.setText("Hello world")
    }
}
