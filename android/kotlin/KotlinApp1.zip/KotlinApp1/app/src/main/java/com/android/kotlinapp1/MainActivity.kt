package com.android.kotlinapp1

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText
import android.widget.Toast
import android.content.Intent

class MainActivity : AppCompatActivity() {
    private var edittext: EditText?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edittext=findViewById(R.id.edittext01)
    }

    fun onClick(view: View){
        edittext?.setText("\"Hello world\"")
    }

    fun onClick1(view: View){
        Toast.makeText(this, edittext?.text,Toast.LENGTH_LONG).show()
    }

    fun onClick2(view: View){
        var intent = Intent(this,MainActivitytwo::class.java)
        startActivity(intent)
    }
}
