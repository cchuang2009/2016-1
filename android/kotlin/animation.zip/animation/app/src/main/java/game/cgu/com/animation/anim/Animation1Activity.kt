package game.cgu.com.animation.anim

import android.animation.ValueAnimator
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import game.cgu.com.animation.R
import kotlinx.android.synthetic.main.animation01.*

class Animation1Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.animation01)

        setupView()
    }

    private fun setupView() {
        title = "ValueAnimator"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        button6.setOnClickListener(goButtonClickHandler)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.getItemId()) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)

    }

    private val goButtonClickHandler = View.OnClickListener { view ->
        val animator = ValueAnimator.ofFloat(0f, -1000f, 0f)
        animator.duration = 4000

        animator.addUpdateListener { valueAnimator ->
            val value = valueAnimator?.animatedValue as Float
            ImageView.translationY = value
        }

        animator.start()
    }

}
