package game.cgu.com.animation

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

import android.support.v7.widget.LinearLayoutManager
import android.content.Intent
import android.support.v7.widget.RecyclerView
//import android.support.v7.widget.RecyclerView
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
import game.cgu.com.animation.anim.Animation1Activity
import game.cgu.com.animation.anim.Animation2Activity
import game.cgu.com.animation.MainAdapter

import kotlinx.android.synthetic.main.activity_main.*
//import kotlinx.android.synthetic.main.item_main.view.*
//import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mRecyclerView01.layoutManager = LinearLayoutManager(this)

        mRecyclerView01.adapter = MainAdapter {
            position:Int -> tapHandler(position)
        }

    }

    private fun tapHandler(position:Int) {
        when(position){
            0 -> {
                val intent = Intent(this, Animation1Activity::class.java)
                startActivity(intent)
            }
            1 -> {
                val intent = Intent(this, Animation2Activity::class.java)
                startActivity(intent)
            }
        }
    }

}

