package chat.nctu.com.chatroomapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;
import java.util.Timer;
import java.util.TimerTask;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.os.Handler;

import android.os.HandlerThread;

import nctu.fintech.appmate.*;

public class MainActivity extends Activity {
    private TextView TextView1;    // 用來顯示文字訊息
    private EditText EditText1;    // 文字方塊
    Button B1;
    String S1 = "Hello World!";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd hh-mm-ss");
    String format = simpleDateFormat.format(new Date());
    //int i=1;
    private Handler mUI_Handler = new Handler();
    private Handler mThreadHandler;
    private Handler mHandler = new Handler();
    private HandlerThread mThread;


    // This gets executed in a non-UI thread:
    public void receiveMyMessage() {
        final String str = "hello world";
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                // This gets executed on the UI thread so it can safely modify Views
                TextView result = (TextView) findViewById(R.id.textview1);
                result.setText(str);
            }
        });
    }

    Table mTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Timer timer01 = new Timer();
        timer01.schedule(task, 0, 3000);

        Button B1 = (Button) findViewById(R.id.button1);
        //B1.setOnClickListener(Func);
        mTable = new Table("http://tz.firc.tw:4000", "major", "demo", "demo");
        B1.setOnClickListener(b1cl);
    }

    private OnClickListener Func = new OnClickListener() {
        public void onClick(View v) {
            EditText editText = (EditText) findViewById(R.id.edittext1);
            CharSequence text = editText.getText();
            TextView result = (TextView) findViewById(R.id.textview1);
            result.setText(text);
        }
    };

    private View.OnClickListener b1cl = new View.OnClickListener() {
        public void onClick(View v) {
            Thread t1 = new Thread(r1);
            t1.start();
        }
    };


    private Runnable r1 = new Runnable() {
        public void run() {
            //mHandler.post(receiveMyMessage);
            mUI_Handler.post(r2);
        }
    };
    private Runnable r2 = new Runnable() {
        public void run() {
            EditText editText = (EditText) findViewById(R.id.edittext1);
            CharSequence text = editText.getText();
            TextView result = (TextView) findViewById(R.id.textview1);
            format = simpleDateFormat.format(new Date());
            result.setText("[ "+format+" ]:\n "+text);

            /*
            Tuple tuple_add = new Tuple();
            tuple_add.put("char32", "hello world!");
            try {
                CharSequence text=mTable.get(tuple_add);
                TextView result=(TextView)findViewById(R.id.textview1);
                //result.setText(text);
                format = simpleDateFormat.format(new Date());
                result.setText("[ "+format+" ]:\n "+text);
            } catch (IOException e) {
                e.printStackTrace();
            }
            */
        }
    };

    
    private TimerTask task = new TimerTask() {
        public void run() {
            Thread t2 = new Thread(r1);
            t2.start();
            //mUI_Handler.post(r2);
        }
    };


}