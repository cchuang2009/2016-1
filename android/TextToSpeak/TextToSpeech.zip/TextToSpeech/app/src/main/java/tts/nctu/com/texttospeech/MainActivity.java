package tts.nctu.com.texttospeech;

//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
//import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.app.AlertDialog;


public class MainActivity extends Activity {

    private EditText mEditText;
    //private TextView mTextView;
    private Button mBtnNormal,mBtnMan,mBtnWoman;
    private Intent intent;
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mEditText = (EditText) findViewById(R.id.wordToSpeak);
        //mTextView = (TextView)  findViewById(R.id.textview1);
        mBtnNormal = (Button) findViewById(R.id.btnNormal);
        mBtnMan = (Button) findViewById(R.id.btnMan);
        mBtnWoman = (Button) findViewById(R.id.btnWoman);

        mBtnNormal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tts.setPitch((float) 1);
                tts.setSpeechRate((float) 1);
                String textToSpeak = mEditText.getText().toString();
                speak(textToSpeak);
            }
        });

        mBtnMan.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tts.setPitch((float) 0.5);
                tts.setSpeechRate((float) 0.8);
                String textToSpeak = mEditText.getText().toString();
                speak(textToSpeak);
            }
        });
        mBtnWoman.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tts.setPitch((float) 2);
                tts.setSpeechRate((float) 1.5);
                String textToSpeak = mEditText.getText().toString();
                speak(textToSpeak);
            }
        });

        tts=new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.US);
                } else {
                    Toast.makeText(MainActivity.this,"Initialization Failed!",Toast.LENGTH_LONG).show();
                }
            }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        // 設定辨識語言 ( 這邊設定的是繁體中文 )
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-TW");
        // 設定語音辨識視窗的內容
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening...");
        startActivityForResult(intent, 1);

    }

    private void speak(String textToSpeak){
        tts.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null);
    }


    public void onInit(int status) {

        // status can be either TextToSpeech.SUCCESS or TextToSpeech.ERROR
        if (status == TextToSpeech.SUCCESS) {
            // Set preferred language to US english.
            // Note that a language may not be available, and the result will indicate this.
            int result = tts.setLanguage(Locale.US);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Lanuage data is missing or the language is not supported.
                Log.e("404","Language is not available.");
            }
        } else {
            // Initialization failed.
            Log.e("404", "Could not initialize TextToSpeech.");
            // May be its not installed so we prompt it to be installed
            Intent installIntent = new Intent();
            installIntent.setAction(
                    TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
            startActivity(installIntent);
        }

    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        // 用來儲存最後的辨識結果
        String firstMatch;
        if (requestCode == 1 && resultCode == RESULT_OK) {
            // 取出多個辨識結果並儲存在 String 的 ArrayList 中
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            firstMatch = (String) result.get(0);
            mEditText.setText(firstMatch);
        } else {
            firstMatch = " 無法辨識 ";
        }
        // 開啟對話方塊
        //set.title: 設定標題
        //setMessage: 設定顯示訊息 這裡會顯示辨識的結果
        new AlertDialog.Builder(MainActivity.this)
                .setTitle(" 語音辨識結果 ")
                .setIcon(android.R.drawable.ic_menu_search)
                .setMessage(firstMatch.toString())
                .setPositiveButton("OK", null).show();
    }

}
