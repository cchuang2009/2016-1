"""
Useage:

import tw_matplotlib
"""
from tw_matplotlib.tw_matplotlib import taiwanize, get_font_path, get_font_ttf_path
